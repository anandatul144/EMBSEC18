# esp32-ota-https (ESP32 Secure over-the-air update)

esp32-ota-https is a demo application that shows how to securely download new firmware images to an ESP32 board. 

More information is available on our blog: https://blog.classycode.com/secure-over-the-air-updates-for-esp32-ec25ae00db43 

